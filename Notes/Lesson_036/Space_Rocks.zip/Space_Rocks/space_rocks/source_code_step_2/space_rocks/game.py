import pygame # Εισαγωγή της βιβλιοθήκης για να αποκτήσουμε όλες τις λειτουργίες της

class SpaceRocks: # Δημιουργία της κλάσης SpaceRocks
    def __init__(self): # Κατασκευαστής
        self._init_pygame() # Προετοιμασία του παιχνιδιού
        self.screen = pygame.display.set_mode((800, 600)) # Επιφάνεια/Πλαίσιο του παιχνιδιού

    def main_loop(self):
        while True:
            self._handle_input() # Διαχείριση των εισόδων από πλ/γιο και ποντίκι
            self._process_game_logic() # Όλη η λογική του παιχνιδιού, κανόνες, συγκρούσεις, νικητής ή χαμένος του παιχνιδιού
            self._draw() # Σχεδιασμός όλων των γραφικών στοιχείων

    def _init_pygame(self): # Προετοιμασία του παιχνιδιού
        pygame.init() # Αρχή του παιχνιδιού
        pygame.display.set_caption("Space Rocks") # Κείμενο/Όνομα του παιχνιδιού

    def _handle_input(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT or (event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE ):
                quit()

    def _process_game_logic(self): # Χειρισμός λογικής
        pass

    def _draw(self): # Όλα τα γραφικά του παιχνιδιού
        self.screen.fill((0, 0, 255)) # Γέμισμα με ένα χρώμα - θα αντικατασταθεί με εικόνα παρακάτω
        pygame.display.flip() # Κλήση επαναδημιουργίας της οθόνης σε κάθε καρέ

