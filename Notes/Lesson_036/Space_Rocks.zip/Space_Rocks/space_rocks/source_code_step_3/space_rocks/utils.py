from pygame.image import load # εισαγωγή μεθόδου load για ανάγνωση εικόνων


def load_sprite(name, with_alpha=True): # εισαγωγή εικόνας με διαφάνεια
    path = f"assets/sprites/space.png" # διαδρομή προς το αρχείο εικόνας
    loaded_sprite = load(path)

    if with_alpha:
        return loaded_sprite.convert_alpha() # χρήση της convert_alpha() για φόρτωση της εικόνας
    else:
        return loaded_sprite.convert() # χρήση της convert() για φόρτωση της εικόνας
