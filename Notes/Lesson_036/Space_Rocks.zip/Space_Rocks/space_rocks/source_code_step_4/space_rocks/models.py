from pygame.math import Vector2


class GameObject: # Κλάση για χειρισμό των αντικειμένων του παιχνιδιού
    def __init__(self, position, sprite, velocity): # Κατασκευαστής με τα ανάλογα ορίσματα
        self.position = Vector2(position) # η Vector2() με όρισμα τη θέση / κέντρο του αντικειμένου
        self.sprite = sprite # ανάθεση μεταβλητής για εικονίδιο/αντικείμενο
        self.radius = sprite.get_width() / 2 # Ορισμός της ακτίνας = πλάτος αντικ. / 2
        self.velocity = Vector2(velocity) # Ορισμός της ταχύτητας και συσχέτιση με την Vector2()

    def draw(self, surface):
        blit_position = self.position - Vector2(self.radius) # Ορισμός θέσης του αντικειμένου
        surface.blit(self.sprite, blit_position) # Τοποθέτηση του αντικειμένου

    def move(self):
        self.position = self.position + self.velocity # Κίνηση αντικειμένων

    def collides_with(self, other_obj): # Σύγκρουση
        distance = self.position.distance_to(other_obj.position) # Υπολογισμός απόστασης
        return distance < self.radius + other_obj.radius # Επιστροφή μόνο αν υπάρχει σύγκρουση
