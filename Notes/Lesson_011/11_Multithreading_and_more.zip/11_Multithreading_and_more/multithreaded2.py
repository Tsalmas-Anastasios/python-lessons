import time
import threading as th

# Δημιουργία μεγέθους λίστας και λίστας
list_size = 500
my_list = []

# Γέμισμα λίστας
for i in range(1, (list_size+1)):
    my_list.append(i)

# Συνάρτηση εκτύπωσης λίστας με παραμέτρους στη range()
def multi_print(offset, max_value):
    # offset = το τέλος του προηγούμενου thread
    # max_value = το τέλος του τρέχοντος thread

    # Εκτύπωση συγκεκριμένων κομματιών της λίστας
    for k in range((0+offset), max_value):

        print(f"{my_list[k]} ")

# Δημιουργία 4 threads (νημάτων) με ονόματα t1, t2, t3, t4 και με παραμέτρους:
# target = είναι η συνάρτηση που θέλουμε να εκτελεί το thread,
# args = τα ορίσματα που θέλουμε να περάσει το thread στη συνάρτηση
t1 = th.Thread(target=multi_print, args=(0, 125))

t2 = th.Thread(target=multi_print, args=(125, 250))

t3 = th.Thread(target=multi_print, args=(250, 375))

t4 = th.Thread(target=multi_print, args=(375, 500))

# Έναρξη καταμέτρησης χρόνου
start = time.time()

# Χωρίς start() δεν ξεκινούν τα threads
# Εκκίνηση των threads
t1.start()

t2.start()

t3.start()

t4.start()

# Αναμονή εκτέλεσης των threads για συνέχεια του προγράμματος και
# ολοκλήρωση των threads πριν το τέλος του προγράμματος 
t1.join()

t2.join()

t3.join()

t4.join()


# Τέλος καταμέτρησης χρόνου
end = time.time()

print(f"Thread time = {end-start} ")
