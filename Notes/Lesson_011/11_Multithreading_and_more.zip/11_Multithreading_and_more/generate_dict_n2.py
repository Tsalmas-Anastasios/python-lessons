print('Δώστε έναν αριθμό ')
n = int(input())
ans = {i:i*i for i in range(1, n+1)}
print(ans[])
