'''
Σας δίνεται μια συμβολοσειρά. Πρέπει να μετρήσετε τη συχνότητα των γραμμάτων της συμβολοσειράς και να τυπώσετε τον αριθμό των γραμμάτων με φθίνουσα σειρά συχνότητας.
Αν δοθεί για παράδειγμα η συμβολοσειρά: aabbbccde, η έξοδος του προγράμματος πρέπει να είναι: b 3 a 2 c 2 d 1 e 1
(Χρησιμοποιείστε Αγγλικές φράσεις. Θα χρειαστεί να χρησιμοποιήσετε λεξικά, καθώς και τη συνάρτηση sorted() για να ταξινομήσετε το αντίστοιχο λεξικό με φθίνουσα σειρά συχνότητας, όπως ζητείται. Μην προσπαθήσετε να χρησιμοποιήσετε dictionary comprehension εδώ, καθότι θα χρειαστεί επίσης να χρησιμοποιήσετε lamda functions που δεν έχουμε διδαχθεί).



input_str = input("Please type a string: ")

# Δημιουργούμε ένα κενό λεξικό για να δεχθεί τη συχνότητα των γραμμάτων
freq_dict = {}

# Διαπερνάμε κάθε χαρακτήρα της εισόδου και ενημερώνουμε το λεξικό

for char in input_str:
    if char in freq_dict:
        freq_dict[char] += 1
    else:
        freq_dict[char] = 1

# Συνάρτηση για χρήση του δευτερου στοιχειου του λεξικού (της τιμής)
def take_second(item):
    return item[1]

# Ταξινομούμε σύμφωνα με την τιμή (συχνότητα) σε φθίνουσα σειρά

sorted_dict = {k: v for k, v in sorted(freq_dict.items(),  key=lambda item: item[1], reverse=True)}

# Εκτύπωση ταξινομηνένου λεξικού
for key, value in sorted_dict.items():
    print(f" {key} {value}", end="")



'''









input_str = input("Please type a string: ")

# Δημιουργούμε ένα κενό λεξικό για να δεχθεί τη συχνότητα των γραμμάτων
freq_dict = {}

# Διαπερνάμε κάθε χαρακτήρα της εισόδου και ενημερώνουμε το λεξικό

for char in input_str:
    if char in freq_dict:
        freq_dict[char] += 1
    else:
        freq_dict[char] = 1

# Ταξινομούμε σύμφωνα με την τιμή (συχνότητα) σε φθίνουσα σειρά

sorted_dict = {k: v for k, v in sorted(freq_dict.items(),  key=lambda item: item[1], reverse=True)}

# Εκτύπωση ταξινομηνένου λεξικού
for key, value in sorted_dict.items():
    print(f" {key} {value}", end="")



