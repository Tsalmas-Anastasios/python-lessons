# Παράδειγμα εκτέλεσης προγράμματος χωρίς multithreading

import time

# Δημιουργία μεταβλητής μεγέθους λίστας και λίστας

list_size = 500

list_of_ints = []

# Γέμισμα λίστας

for i in range(0, (list_size+1)):

    list_of_ints.append(i)

# Συνάρτηση εκτύπωσης λίστας σε ένα thread

def single_print():

    for k in range(int(list_size+1)):

        print(list_of_ints[k])
    
# Αρχή καταμέτρησης χρόνου
singlethread_start_time = time.time()

# Εκτύπωση
single_print()

# Τέλος καταμέτρησης χρόνου
singlethread_end_time = time.time()

# Υπολογισμός χρόνου εκτέλεσης
singlethread_final_time = singlethread_end_time - singlethread_start_time

print(f"\nΧρόνος εκτέλεσης συνάρτησης one-thread: {singlethread_final_time}")
