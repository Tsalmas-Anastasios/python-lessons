input_str = input("Please type a string: ")

# Δημιουργούμε ένα κενό λεξικό για να δεχθεί τη συχνότητα των γραμμάτων
freq_dict = {}

# Διαπερνάμε κάθε χαρακτήρα της εισόδου και ενημερώνουμε το λεξικό

for char in input_str:
    if char in freq_dict:
        freq_dict[char] += 1
    else:
        freq_dict[char] = 1

# Συνάρτηση για χρήση του δευτερου στοιχειου του λεξικού (της τιμής)
def take_second(item):
    return item[1]

# Ταξινομούμε σύμφωνα με την τιμή (συχνότητα) σε φθίνουσα σειρά

sorted_dict = {k: v for k, v in sorted(freq_dict.items(),  key=take_second, reverse=True)}

# Εκτύπωση ταξινομηνένου λεξικού
for key, value in sorted_dict.items():
    print(f" {key} {value}", end="")
